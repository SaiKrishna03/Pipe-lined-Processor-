/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "Cin %b";
static const char *ng1 = "cout1 %b";
static const char *ng2 = "C:/Users/Sai krishna/ALU/dflipflop_64.v";

void Monitor_95_1(char *);
void Monitor_99_3(char *);
void Monitor_95_1(char *);
void Monitor_99_3(char *);


static void Monitor_95_1_Func(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1208U);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 3, ng0, 2, t0, (char)118, t2, 65);

LAB1:    return;
}

static void Monitor_99_3_Func(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1368U);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 3, ng1, 2, t0, (char)118, t2, 65);

LAB1:    return;
}

static void Initial_94_0(char *t0)
{

LAB0:    xsi_set_current_line(94, ng2);

LAB2:    xsi_set_current_line(95, ng2);
    Monitor_95_1(t0);

LAB1:    return;
}

static void Initial_98_2(char *t0)
{

LAB0:    xsi_set_current_line(98, ng2);

LAB2:    xsi_set_current_line(99, ng2);
    Monitor_99_3(t0);

LAB1:    return;
}

void Monitor_95_1(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 2992);
    t2 = (t0 + 3752);
    xsi_vlogfile_monitor((void *)Monitor_95_1_Func, t1, t2);

LAB1:    return;
}

void Monitor_99_3(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 3240);
    t2 = (t0 + 3768);
    xsi_vlogfile_monitor((void *)Monitor_99_3_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000001710258859_0691142319_init()
{
	static char *pe[] = {(void *)Initial_94_0,(void *)Initial_98_2,(void *)Monitor_95_1,(void *)Monitor_99_3};
	xsi_register_didat("work_m_00000000001710258859_0691142319", "isim/processor_isim_beh.exe.sim/work/m_00000000001710258859_0691142319.didat");
	xsi_register_executes(pe);
}
