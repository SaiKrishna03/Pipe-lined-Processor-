/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "p %b";
static const char *ng1 = "s %b";
static const char *ng2 = "cout %b";
static const char *ng3 = "C:/Users/Sai krishna/ALU/sum_module.v";

void Monitor_46_4(char *);
void Monitor_50_6(char *);
void Monitor_54_8(char *);
void Monitor_46_4(char *);
void Monitor_50_6(char *);
void Monitor_54_8(char *);


static void Monitor_46_4_Func(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 2008U);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 3, ng0, 2, t0, (char)118, t2, 32);

LAB1:    return;
}

static void Monitor_50_6_Func(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1688U);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 3, ng1, 2, t0, (char)118, t2, 32);

LAB1:    return;
}

static void Monitor_54_8_Func(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1848U);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 3, ng2, 2, t0, (char)118, t2, 1);

LAB1:    return;
}

static void Cont_40_0(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;

LAB0:    t1 = (t0 + 3968U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng3);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t0 + 1208U);
    t4 = *((char **)t2);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t4);
    t8 = (t6 ^ t7);
    *((unsigned int *)t5) = t8;
    t2 = (t3 + 4);
    t9 = (t4 + 4);
    t10 = (t5 + 4);
    t11 = *((unsigned int *)t2);
    t12 = *((unsigned int *)t9);
    t13 = (t11 | t12);
    *((unsigned int *)t10) = t13;
    t14 = *((unsigned int *)t10);
    t15 = (t14 != 0);
    if (t15 == 1)
        goto LAB4;

LAB5:
LAB6:    t18 = (t0 + 6432);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t5, 8);
    xsi_driver_vfirst_trans(t18, 0, 31);
    t23 = (t0 + 6272);
    *((int *)t23) = 1;

LAB1:    return;
LAB4:    t16 = *((unsigned int *)t5);
    t17 = *((unsigned int *)t10);
    *((unsigned int *)t5) = (t16 | t17);
    goto LAB6;

}

static void Cont_41_1(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;

LAB0:    t1 = (t0 + 4216U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(41, ng3);
    t2 = (t0 + 2008U);
    t3 = *((char **)t2);
    t2 = (t0 + 2328U);
    t4 = *((char **)t2);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t4);
    t8 = (t6 ^ t7);
    *((unsigned int *)t5) = t8;
    t2 = (t3 + 4);
    t9 = (t4 + 4);
    t10 = (t5 + 4);
    t11 = *((unsigned int *)t2);
    t12 = *((unsigned int *)t9);
    t13 = (t11 | t12);
    *((unsigned int *)t10) = t13;
    t14 = *((unsigned int *)t10);
    t15 = (t14 != 0);
    if (t15 == 1)
        goto LAB4;

LAB5:
LAB6:    t18 = (t0 + 6496);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t5, 8);
    xsi_driver_vfirst_trans(t18, 0, 31);
    t23 = (t0 + 6288);
    *((int *)t23) = 1;

LAB1:    return;
LAB4:    t16 = *((unsigned int *)t5);
    t17 = *((unsigned int *)t10);
    *((unsigned int *)t5) = (t16 | t17);
    goto LAB6;

}

static void Cont_42_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t1 = (t0 + 4464U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(42, ng3);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    t2 = (t0 + 6560);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t2, 0, 0);
    t16 = (t0 + 6304);
    *((int *)t16) = 1;

LAB1:    return;
}

static void Initial_45_3(char *t0)
{

LAB0:    xsi_set_current_line(45, ng3);

LAB2:    xsi_set_current_line(46, ng3);
    Monitor_46_4(t0);

LAB1:    return;
}

static void Initial_49_5(char *t0)
{

LAB0:    xsi_set_current_line(49, ng3);

LAB2:    xsi_set_current_line(50, ng3);
    Monitor_50_6(t0);

LAB1:    return;
}

static void Initial_53_7(char *t0)
{

LAB0:    xsi_set_current_line(53, ng3);

LAB2:    xsi_set_current_line(54, ng3);
    Monitor_54_8(t0);

LAB1:    return;
}

void Monitor_46_4(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 5264);
    t2 = (t0 + 6320);
    xsi_vlogfile_monitor((void *)Monitor_46_4_Func, t1, t2);

LAB1:    return;
}

void Monitor_50_6(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 5512);
    t2 = (t0 + 6336);
    xsi_vlogfile_monitor((void *)Monitor_50_6_Func, t1, t2);

LAB1:    return;
}

void Monitor_54_8(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 5760);
    t2 = (t0 + 6352);
    xsi_vlogfile_monitor((void *)Monitor_54_8_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000003523161752_2482865015_init()
{
	static char *pe[] = {(void *)Cont_40_0,(void *)Cont_41_1,(void *)Cont_42_2,(void *)Initial_45_3,(void *)Initial_49_5,(void *)Initial_53_7,(void *)Monitor_46_4,(void *)Monitor_50_6,(void *)Monitor_54_8};
	xsi_register_didat("work_m_00000000003523161752_2482865015", "isim/a_l_u_tb_isim_beh.exe.sim/work/m_00000000003523161752_2482865015.didat");
	xsi_register_executes(pe);
}
