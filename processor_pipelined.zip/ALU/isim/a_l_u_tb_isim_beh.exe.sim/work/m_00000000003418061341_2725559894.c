/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Sai krishna/ALU/a_l_u.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {32U, 0U};
static unsigned int ng3[] = {33U, 0U};
static unsigned int ng4[] = {34U, 0U};
static unsigned int ng5[] = {35U, 0U};
static unsigned int ng6[] = {36U, 0U};
static unsigned int ng7[] = {37U, 0U};
static unsigned int ng8[] = {46U, 0U};
static unsigned int ng9[] = {47U, 0U};
static unsigned int ng10[] = {38U, 0U};
static unsigned int ng11[] = {39U, 0U};
static unsigned int ng12[] = {42U, 0U};
static int ng13[] = {1, 0};
static unsigned int ng14[] = {43U, 0U};



static void Cont_40_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 4448U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5096);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void Always_48_1(char *t0)
{
    char t9[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;
    char *t10;

LAB0:    t1 = (t0 + 4696U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 5016);
    *((int *)t2) = 1;
    t3 = (t0 + 4728);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(49, ng0);

LAB5:    xsi_set_current_line(50, ng0);
    t4 = (t0 + 1368U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng2)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t4, 6);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng3)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng4)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng6)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng8)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng9)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng10)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng11)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng12)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng14)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB29;

LAB30:
LAB31:    goto LAB2;

LAB7:    xsi_set_current_line(52, ng0);
    t7 = (t0 + 1848U);
    t8 = *((char **)t7);
    memcpy(t9, t8, 8);
    t7 = (t9 + 8);
    memset(t7, 0, 8);
    t10 = (t0 + 3208);
    xsi_vlogvar_assign_value(t10, t9, 0, 0, 64);
    goto LAB31;

LAB9:    xsi_set_current_line(53, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t0 + 1208U);
    t7 = *((char **)t3);
    xsi_vlog_unsigned_minus(t9, 64, t4, 32, t7, 32);
    t3 = (t0 + 3208);
    xsi_vlogvar_assign_value(t3, t9, 0, 0, 64);
    goto LAB31;

LAB11:    xsi_set_current_line(54, ng0);
    t3 = (t0 + 2008U);
    t4 = *((char **)t3);
    t3 = (t0 + 3208);
    xsi_vlogvar_assign_value(t3, t4, 0, 0, 64);
    goto LAB31;

LAB13:    xsi_set_current_line(55, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = (t0 + 1208U);
    t7 = *((char **)t3);
    xsi_vlog_unsigned_divide(t9, 64, t4, 32, t7, 32);
    t3 = (t0 + 3208);
    xsi_vlogvar_assign_value(t3, t9, 0, 0, 64);
    goto LAB31;

LAB15:    xsi_set_current_line(56, ng0);
    t3 = (t0 + 2168U);
    t4 = *((char **)t3);
    memcpy(t9, t4, 8);
    t3 = (t9 + 8);
    memset(t3, 0, 8);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t9, 0, 0, 64);
    goto LAB31;

LAB17:    xsi_set_current_line(57, ng0);
    t3 = (t0 + 2328U);
    t4 = *((char **)t3);
    memcpy(t9, t4, 8);
    t3 = (t9 + 8);
    memset(t3, 0, 8);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t9, 0, 0, 64);
    goto LAB31;

LAB19:    xsi_set_current_line(59, ng0);
    t3 = (t0 + 1688U);
    t4 = *((char **)t3);
    memcpy(t9, t4, 8);
    t3 = (t9 + 8);
    memset(t3, 0, 8);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t9, 0, 0, 64);
    goto LAB31;

LAB21:    xsi_set_current_line(60, ng0);
    t3 = (t0 + 1688U);
    t4 = *((char **)t3);
    memcpy(t9, t4, 8);
    t3 = (t9 + 8);
    memset(t3, 0, 8);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t9, 0, 0, 64);
    goto LAB31;

LAB23:    xsi_set_current_line(61, ng0);
    t3 = (t0 + 1688U);
    t4 = *((char **)t3);
    memcpy(t9, t4, 8);
    t3 = (t9 + 8);
    memset(t3, 0, 8);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t9, 0, 0, 64);
    goto LAB31;

LAB25:    xsi_set_current_line(62, ng0);
    t3 = (t0 + 1688U);
    t4 = *((char **)t3);
    memcpy(t9, t4, 8);
    t3 = (t9 + 8);
    memset(t3, 0, 8);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t9, 0, 0, 64);
    goto LAB31;

LAB27:    xsi_set_current_line(63, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng13)));
    xsi_vlog_unsigned_rshift(t9, 64, t4, 32, t3, 32);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t9, 0, 0, 64);
    goto LAB31;

LAB29:    xsi_set_current_line(64, ng0);
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng13)));
    xsi_vlog_unsigned_lshift(t9, 64, t4, 32, t3, 32);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t9, 0, 0, 64);
    goto LAB31;

}


extern void work_m_00000000003418061341_2725559894_init()
{
	static char *pe[] = {(void *)Cont_40_0,(void *)Always_48_1};
	xsi_register_didat("work_m_00000000003418061341_2725559894", "isim/a_l_u_tb_isim_beh.exe.sim/work/m_00000000003418061341_2725559894.didat");
	xsi_register_executes(pe);
}
