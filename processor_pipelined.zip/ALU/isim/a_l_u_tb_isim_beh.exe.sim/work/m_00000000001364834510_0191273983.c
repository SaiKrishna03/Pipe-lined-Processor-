/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "a=%b carry=%b sign=%b zero=%b";
static const char *ng1 = "C:/Users/Sai krishna/ALU/zeros.v";
static int ng2[] = {0, 0};
static int ng3[] = {23, 0};
static int ng4[] = {1, 0};

void Monitor_61_3(char *);
void Monitor_61_3(char *);


static void Monitor_61_3_Func(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;

LAB0:    t1 = (t0 + 1208U);
    t2 = *((char **)t1);
    t1 = (t0 + 1048U);
    t3 = *((char **)t1);
    t1 = (t0 + 1368U);
    t4 = *((char **)t1);
    t1 = (t0 + 1768);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    xsi_vlogfile_write(1, 0, 3, ng0, 5, t0, (char)118, t2, 24, (char)118, t3, 1, (char)118, t4, 1, (char)118, t6, 8);

LAB1:    return;
}

static void Initial_32_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(32, ng1);

LAB2:    xsi_set_current_line(33, ng1);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 1768);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 8);

LAB1:    return;
}

static void Always_36_1(char *t0)
{
    char t7[8];
    char t31[8];
    char t34[8];
    char t48[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    char *t32;
    char *t33;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;

LAB0:    t1 = (t0 + 3096U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng1);
    t2 = (t0 + 3912);
    *((int *)t2) = 1;
    t3 = (t0 + 3128);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(37, ng1);

LAB5:    xsi_set_current_line(39, ng1);
    t4 = (t0 + 2904);
    xsi_process_wait(t4, 600000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(39, ng1);
    t5 = (t0 + 1048U);
    t6 = *((char **)t5);
    t5 = ((char*)((ng2)));
    memset(t7, 0, 8);
    t8 = (t6 + 4);
    t9 = (t5 + 4);
    t10 = *((unsigned int *)t6);
    t11 = *((unsigned int *)t5);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t8);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = (t12 | t15);
    t17 = *((unsigned int *)t8);
    t18 = *((unsigned int *)t9);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB10;

LAB7:    if (t19 != 0)
        goto LAB9;

LAB8:    *((unsigned int *)t7) = 1;

LAB10:    t23 = (t7 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t7);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB11;

LAB12:
LAB13:    xsi_set_current_line(47, ng1);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng4)));
    memset(t7, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t10 = *((unsigned int *)t3);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t5);
    t15 = (t13 ^ t14);
    t16 = (t12 | t15);
    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t5);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB30;

LAB27:    if (t19 != 0)
        goto LAB29;

LAB28:    *((unsigned int *)t7) = 1;

LAB30:    t8 = (t7 + 4);
    t24 = *((unsigned int *)t8);
    t25 = (~(t24));
    t26 = *((unsigned int *)t7);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB31;

LAB32:
LAB33:    goto LAB2;

LAB9:    t22 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t22) = 1;
    goto LAB10;

LAB11:    xsi_set_current_line(39, ng1);

LAB14:    xsi_set_current_line(40, ng1);
    xsi_set_current_line(40, ng1);
    t29 = ((char*)((ng3)));
    t30 = (t0 + 1928);
    xsi_vlogvar_assign_value(t30, t29, 0, 0, 32);

LAB15:    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t7, 0, 8);
    xsi_vlog_signed_greatereq(t7, 32, t4, 32, t5, 32);
    t6 = (t7 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (~(t10));
    t12 = *((unsigned int *)t7);
    t13 = (t12 & t11);
    t14 = (t13 != 0);
    if (t14 > 0)
        goto LAB16;

LAB17:    goto LAB13;

LAB16:    xsi_set_current_line(40, ng1);

LAB18:    xsi_set_current_line(41, ng1);
    t8 = (t0 + 1208U);
    t9 = *((char **)t8);
    t8 = (t0 + 1168U);
    t22 = (t8 + 72U);
    t23 = *((char **)t22);
    t29 = (t0 + 1928);
    t30 = (t29 + 56U);
    t32 = *((char **)t30);
    xsi_vlog_generic_get_index_select_value(t31, 32, t9, t23, 2, t32, 32, 1);
    t33 = ((char*)((ng4)));
    memset(t34, 0, 8);
    t35 = (t31 + 4);
    t36 = (t33 + 4);
    t15 = *((unsigned int *)t31);
    t16 = *((unsigned int *)t33);
    t17 = (t15 ^ t16);
    t18 = *((unsigned int *)t35);
    t19 = *((unsigned int *)t36);
    t20 = (t18 ^ t19);
    t21 = (t17 | t20);
    t24 = *((unsigned int *)t35);
    t25 = *((unsigned int *)t36);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t28 = (t21 & t27);
    if (t28 != 0)
        goto LAB20;

LAB19:    if (t26 != 0)
        goto LAB21;

LAB22:    t38 = (t34 + 4);
    t39 = *((unsigned int *)t38);
    t40 = (~(t39));
    t41 = *((unsigned int *)t34);
    t42 = (t41 & t40);
    t43 = (t42 != 0);
    if (t43 > 0)
        goto LAB23;

LAB24:
LAB25:    xsi_set_current_line(40, ng1);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t7, 0, 8);
    xsi_vlog_signed_minus(t7, 32, t4, 32, t5, 32);
    t6 = (t0 + 1928);
    xsi_vlogvar_assign_value(t6, t7, 0, 0, 32);
    goto LAB15;

LAB20:    *((unsigned int *)t34) = 1;
    goto LAB22;

LAB21:    t37 = (t34 + 4);
    *((unsigned int *)t34) = 1;
    *((unsigned int *)t37) = 1;
    goto LAB22;

LAB23:    xsi_set_current_line(41, ng1);

LAB26:    xsi_set_current_line(42, ng1);
    t44 = (t0 + 1768);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    t47 = ((char*)((ng4)));
    memset(t48, 0, 8);
    xsi_vlog_unsigned_add(t48, 32, t46, 8, t47, 32);
    t49 = (t0 + 1768);
    xsi_vlogvar_assign_value(t49, t48, 0, 0, 8);
    goto LAB25;

LAB29:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB30;

LAB31:    xsi_set_current_line(47, ng1);

LAB34:    xsi_set_current_line(48, ng1);
    t9 = (t0 + 1368U);
    t22 = *((char **)t9);
    t9 = ((char*)((ng4)));
    memset(t31, 0, 8);
    t23 = (t22 + 4);
    t29 = (t9 + 4);
    t39 = *((unsigned int *)t22);
    t40 = *((unsigned int *)t9);
    t41 = (t39 ^ t40);
    t42 = *((unsigned int *)t23);
    t43 = *((unsigned int *)t29);
    t50 = (t42 ^ t43);
    t51 = (t41 | t50);
    t52 = *((unsigned int *)t23);
    t53 = *((unsigned int *)t29);
    t54 = (t52 | t53);
    t55 = (~(t54));
    t56 = (t51 & t55);
    if (t56 != 0)
        goto LAB38;

LAB35:    if (t54 != 0)
        goto LAB37;

LAB36:    *((unsigned int *)t31) = 1;

LAB38:    t32 = (t31 + 4);
    t57 = *((unsigned int *)t32);
    t58 = (~(t57));
    t59 = *((unsigned int *)t31);
    t60 = (t59 & t58);
    t61 = (t60 != 0);
    if (t61 > 0)
        goto LAB39;

LAB40:
LAB41:    goto LAB33;

LAB37:    t30 = (t31 + 4);
    *((unsigned int *)t31) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB38;

LAB39:    xsi_set_current_line(48, ng1);

LAB42:    xsi_set_current_line(49, ng1);
    xsi_set_current_line(49, ng1);
    t33 = ((char*)((ng3)));
    t35 = (t0 + 1928);
    xsi_vlogvar_assign_value(t35, t33, 0, 0, 32);

LAB43:    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t7, 0, 8);
    xsi_vlog_signed_greatereq(t7, 32, t4, 32, t5, 32);
    t6 = (t7 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (~(t10));
    t12 = *((unsigned int *)t7);
    t13 = (t12 & t11);
    t14 = (t13 != 0);
    if (t14 > 0)
        goto LAB44;

LAB45:    goto LAB41;

LAB44:    xsi_set_current_line(49, ng1);

LAB46:    xsi_set_current_line(50, ng1);
    t8 = (t0 + 1208U);
    t9 = *((char **)t8);
    t8 = (t0 + 1168U);
    t22 = (t8 + 72U);
    t23 = *((char **)t22);
    t29 = (t0 + 1928);
    t30 = (t29 + 56U);
    t32 = *((char **)t30);
    xsi_vlog_generic_get_index_select_value(t31, 32, t9, t23, 2, t32, 32, 1);
    t33 = ((char*)((ng4)));
    memset(t34, 0, 8);
    t35 = (t31 + 4);
    t36 = (t33 + 4);
    t15 = *((unsigned int *)t31);
    t16 = *((unsigned int *)t33);
    t17 = (t15 ^ t16);
    t18 = *((unsigned int *)t35);
    t19 = *((unsigned int *)t36);
    t20 = (t18 ^ t19);
    t21 = (t17 | t20);
    t24 = *((unsigned int *)t35);
    t25 = *((unsigned int *)t36);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t28 = (t21 & t27);
    if (t28 != 0)
        goto LAB48;

LAB47:    if (t26 != 0)
        goto LAB49;

LAB50:    t38 = (t34 + 4);
    t39 = *((unsigned int *)t38);
    t40 = (~(t39));
    t41 = *((unsigned int *)t34);
    t42 = (t41 & t40);
    t43 = (t42 != 0);
    if (t43 > 0)
        goto LAB51;

LAB52:
LAB53:    xsi_set_current_line(49, ng1);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t7, 0, 8);
    xsi_vlog_signed_minus(t7, 32, t4, 32, t5, 32);
    t6 = (t0 + 1928);
    xsi_vlogvar_assign_value(t6, t7, 0, 0, 32);
    goto LAB43;

LAB48:    *((unsigned int *)t34) = 1;
    goto LAB50;

LAB49:    t37 = (t34 + 4);
    *((unsigned int *)t34) = 1;
    *((unsigned int *)t37) = 1;
    goto LAB50;

LAB51:    xsi_set_current_line(50, ng1);

LAB54:    xsi_set_current_line(51, ng1);
    t44 = (t0 + 1768);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    t47 = ((char*)((ng4)));
    memset(t48, 0, 8);
    xsi_vlog_unsigned_add(t48, 32, t46, 8, t47, 32);
    t49 = (t0 + 1768);
    xsi_vlogvar_assign_value(t49, t48, 0, 0, 8);
    goto LAB53;

}

static void Initial_60_2(char *t0)
{

LAB0:    xsi_set_current_line(60, ng1);

LAB2:    xsi_set_current_line(61, ng1);
    Monitor_61_3(t0);

LAB1:    return;
}

void Monitor_61_3(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 3400);
    t2 = (t0 + 3928);
    xsi_vlogfile_monitor((void *)Monitor_61_3_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000001364834510_0191273983_init()
{
	static char *pe[] = {(void *)Initial_32_0,(void *)Always_36_1,(void *)Initial_60_2,(void *)Monitor_61_3};
	xsi_register_didat("work_m_00000000001364834510_0191273983", "isim/a_l_u_tb_isim_beh.exe.sim/work/m_00000000001364834510_0191273983.didat");
	xsi_register_executes(pe);
}
