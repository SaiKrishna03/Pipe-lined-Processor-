/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "Cin %b";
static const char *ng1 = "cout1 %b";
static const char *ng2 = "C:/Users/Sai krishna/ALU/flipflop_module.v";

void Monitor_67_2(char *);
void Monitor_71_4(char *);
void Monitor_67_2(char *);
void Monitor_71_4(char *);


static void Monitor_67_2_Func(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1368U);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 3, ng0, 2, t0, (char)118, t2, 32);

LAB1:    return;
}

static void Monitor_71_4_Func(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1528U);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 3, ng1, 2, t0, (char)118, t2, 32);

LAB1:    return;
}

static void Cont_64_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(64, ng2);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 4432);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t2, 0, 0);
    t16 = (t0 + 4320);
    *((int *)t16) = 1;

LAB1:    return;
}

static void Initial_66_1(char *t0)
{

LAB0:    xsi_set_current_line(66, ng2);

LAB2:    xsi_set_current_line(67, ng2);
    Monitor_67_2(t0);

LAB1:    return;
}

static void Initial_70_3(char *t0)
{

LAB0:    xsi_set_current_line(70, ng2);

LAB2:    xsi_set_current_line(71, ng2);
    Monitor_71_4(t0);

LAB1:    return;
}

void Monitor_67_2(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 3560);
    t2 = (t0 + 4336);
    xsi_vlogfile_monitor((void *)Monitor_67_2_Func, t1, t2);

LAB1:    return;
}

void Monitor_71_4(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 3808);
    t2 = (t0 + 4352);
    xsi_vlogfile_monitor((void *)Monitor_71_4_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000000950441481_0184771711_init()
{
	static char *pe[] = {(void *)Cont_64_0,(void *)Initial_66_1,(void *)Initial_70_3,(void *)Monitor_67_2,(void *)Monitor_71_4};
	xsi_register_didat("work_m_00000000000950441481_0184771711", "isim/a_l_u_tb_isim_beh.exe.sim/work/m_00000000000950441481_0184771711.didat");
	xsi_register_executes(pe);
}
